/**
 * Automatically generated file. DO NOT MODIFY
 */
package dev.oom_wg.purejoy.fyl.fytxt.systxt;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "dev.oom_wg.purejoy.fyl.fytxt.systxt";
  public static final String BUILD_TYPE = "release";
}
