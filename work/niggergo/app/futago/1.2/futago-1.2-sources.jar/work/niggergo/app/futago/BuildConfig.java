/**
 * Automatically generated file. DO NOT MODIFY
 */
package work.niggergo.app.futago;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "work.niggergo.app.futago";
  public static final String BUILD_TYPE = "release";
}
